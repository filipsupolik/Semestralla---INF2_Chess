import hlavnybalicek.ChessGame;

public class Main {
    public static void main(String[] args) {
        ChessGame chessGame = new ChessGame();
        chessGame.startNewGame();
    }
}