package piece;

import enums.PlayerType;
import hlavnybalicek.BoardFrame;

public class Rook extends Piece {

    public Rook(PlayerType playerType, String imagePath, int x, int y) {
        super(playerType, imagePath, x, y);

    }

    @Override
    public boolean isValidMove(BoardFrame fromFrame, BoardFrame toFrame) {
        return true;
    }
}
