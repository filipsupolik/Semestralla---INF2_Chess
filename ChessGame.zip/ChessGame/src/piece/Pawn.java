package piece;

import enums.PlayerType;
import hlavnybalicek.BoardFrame;

public class Pawn extends Piece {

    private int counter;
    private boolean firstMove;

    public Pawn(PlayerType playerType, String imagePath, int x, int y) {
        super( playerType, imagePath, x, y);
        this.counter = 0;
        this.firstMove = true;
    }

    @Override
    public boolean isValidMove(BoardFrame fromFrame, BoardFrame toFrame) {
        int frameFromX = fromFrame.getX();
        int frameFromY = fromFrame.getY();
        int frameToX = toFrame.getX();
        int frameToY = toFrame.getY();
//        if (this.counter == 0) {
//            if (this.getPlayerType().equals(PlayerType.BLACK)) {
//                if (fromFrame.getX())
//            } else {
//
//            }
//        } else {
//            if (this.getPlayerType().equals(PlayerType.BLACK)) {
//
//            } else {
//
//            }
//        }
        if (frameFromX >= 0 && frameFromX <= 7 && frameFromY >= 0 && frameFromY <= 7) {
            if (frameToX >= 0 && frameToX <= 7 && frameToY >= 0 && frameToY <= 7) {
                System.out.println("Spravne");
                return true;
            }
        }
        System.out.println("Nespravne");
        return false;
    }
}
