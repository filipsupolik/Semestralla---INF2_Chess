package enums;

public enum PlayerType {
    WHITE,
    BLACK;
}
